function converterMedidas() {
    // Obter a distância em metros
    var distanciaEmMetros = parseFloat(document.getElementById("distancia").value);

    // Verificar se a entrada é válida
    if (!isNaN(distanciaEmMetros)) {
        // Realizar as conversões
        var distanciaEmQuilometros = distanciaEmMetros / 1000;
        var distanciaEmHectometros = distanciaEmMetros / 100;
        var distanciaEmDecametros = distanciaEmMetros / 10;
        var distanciaEmDecimetros = distanciaEmMetros * 10;
        var distanciaEmCentimetros = distanciaEmMetros * 100;
        var distanciaEmMilimetros = distanciaEmMetros * 1000;

        // Exibir os resultados na seção correspondente
        var resultados = document.getElementById("resultados");
        resultados.innerHTML = "<p>Distância em Quilômetros: " + distanciaEmQuilometros.toFixed(6) + "</p>" +
                               "<p>Distância em Hectômetros: " + distanciaEmHectometros.toFixed(5) + "</p>" +
                               "<p>Distância em Decâmetros: " + distanciaEmDecametros.toFixed(4) + "</p>" +
                               "<p>Distância em Decímetros: " + distanciaEmDecimetros.toFixed(3) + "</p>" +
                               "<p>Distância em Centímetros: " + distanciaEmCentimetros.toFixed(2) + "</p>" +
                               "<p>Distância em Milímetros: " + distanciaEmMilimetros.toFixed(1) + "</p>";
    } else {
        alert("Por favor, digite uma distância válida em metros.");
    }
}
