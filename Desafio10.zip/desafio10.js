document.getElementById("calcularBtn").addEventListener("click", function() {
    var nomeAluno = prompt("Qual é o nome do aluno?");
    if (!nomeAluno) {
        alert("Por favor, insira o nome do aluno.");
    } else {
        var nota1 = parseFloat(prompt("Digite a primeira nota (0 a 20):"));
        if (isNaN(nota1) || nota1 < 0 || nota1 > 20) {
            alert("Por favor, insira uma nota válida (de 0 a 20) para a primeira nota.");
        } else {
            var nota2 = parseFloat(prompt("Digite a segunda nota (0 a 20):"));
            if (isNaN(nota2) || nota2 < 0 || nota2 > 20) {
                alert("Por favor, insira uma nota válida (de 0 a 20) para a segunda nota.");
            } else {
                var media = (nota1 + nota2) / 2;
                var situacao;

                if (media < 7) {
                    situacao = "Reprovado";
                } else if (media >= 7 && media < 10) {
                    situacao = "Recuperação";
                } else {
                    situacao = "Aprovado";
                }

                var resultado = "Nome do Aluno: " + nomeAluno + "<br>";
                resultado += "Primeira Nota: " + nota1.toFixed(2) + "<br>";
                resultado += "Segunda Nota: " + nota2.toFixed(2) + "<br>";
                resultado += "Média do aluno: " + media.toFixed(2) + "<br>";
                resultado += "Situação: ";

                if (situacao === "Aprovado") {
                    resultado += '<span class="aprovado">' + situacao + '</span>';
                } else if (situacao === "Recuperação") {
                    resultado += '<span class="recuperacao">' + situacao + '</span>';
                } else {
                    resultado += '<span class="reprovado">' + situacao + '</span>';
                }

                var resultadoElement = document.getElementById("resultado");
                resultadoElement.innerHTML = resultado;
                resultadoElement.style.display = "block";
            }
        }
    }
});
