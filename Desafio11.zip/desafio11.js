document.getElementById("verificarBtn").addEventListener("click", function() {
    var ano = parseInt(prompt("Digite o ano:"));

    if (isNaN(ano)) {
        alert("Por favor, insira um ano válido.");
    } else {
        var bissexto = (ano % 4 === 0 && ano % 100 !== 0) || (ano % 400 === 0);

        var resultado = "Ano: " + ano + "<br>";
        resultado += "É bissexto: ";

        if (bissexto) {
            resultado += '<span class="bissexto">Sim</span>';
        } else {
            resultado += '<span class="nao-bissexto">Não❌</span>';
        }

        var resultadoElement = document.getElementById("resultado");
        resultadoElement.innerHTML = resultado;
        resultadoElement.style.display = "block";
    }
});
