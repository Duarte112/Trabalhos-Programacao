function scope() {
    console.log(this, arguments.length);
   }
   scope() // window, 0
   scope.call("foobar", [1,2]); //==> "foobar", 1
   scope.apply("foobar", [1,2]); //==> "foobar", 2