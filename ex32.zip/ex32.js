var numbers = [5, 7, 1, 8, 9];

document.getElementById("crescenteButton").addEventListener("click", function() {
    mostrarResultado(numbers.slice().sort(function(a, b) {
        return a - b;
    }));
});

document.getElementById("decrescenteButton").addEventListener("click", function() {
    mostrarResultado(numbers.slice().sort(function(a, b) {
        return b - a;
    }));
});

function mostrarResultado(arrayOrdenado) {
    var resultadoDiv = document.getElementById("resultado");
    resultadoDiv.innerHTML = "Array ordenado: " + arrayOrdenado.join(", ");
}
