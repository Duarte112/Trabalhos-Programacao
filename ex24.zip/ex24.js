function contagem() {
    let saida = document.getElementById('saida');
    let num = Number(document.getElementById('fnum').value);

    // Verifica se o valor inserido é um número positivo
    if (isNaN(num) || num < 0) {
        saida.innerHTML = '<p>Por favor, digite apenas números positivos.</p>';
        return;
    }

    saida.innerHTML = `<h2>Contando de 0 até ${num}</h2>`;
    
    for (let i = 0; i <= num; i++) {
        saida.innerHTML += `<span>${i}</span>`;
    }
}
