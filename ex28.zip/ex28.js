function fatorial() {
    let saida = document.getElementById('saida');
    let n = Number(document.getElementById('fnum').value);

    saida.innerHTML = ''; // Limpa o conteúdo anterior

    if (n >= 1 && n <= 21) { // Verifica se o número está no intervalo permitido
        saida.innerHTML += `<h2>Calculando ${n}!</h2>`;
        
        let c = n;
        let fat = 1;
        
        while (c > 1) {
            fat *= c;
            c--;
        }
        
        saida.innerHTML += `<p>O fatorial de ${n} é ${fat}</p>`;
    } else {
        saida.innerHTML += `<p>Por favor, insira um número entre 1 e 21.</p>`;
    }
}
