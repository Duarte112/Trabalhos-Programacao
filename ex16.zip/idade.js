function calcidade() {
    let agora = new Date();
    let ano = agora.getFullYear();

    let nasc = Number(window.prompt('Em que ano você nasceu?'));
    
    // Calculando a idade
    let idade = ano - nasc;

    // Exibindo a idade na seção "saida"
    let saida = document.getElementById('saida');
    saida.innerHTML = `<p>A sua idade é ${idade} anos.</p>`;
}
