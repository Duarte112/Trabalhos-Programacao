document.getElementById('calcular').addEventListener('click', tabuada);

function tabuada(){
    let saida = document.getElementById('saida');
    let n = Number(document.getElementById('fnum').value);

    saida.innerHTML = `<h2>Tabuada de ${n}</h2>`;
    let c = 1;
    let tabuadaHTML = "<ul>";

    while (c <= 10) {
        tabuadaHTML += `<li>${n} x ${c} = ${n * c}</li>`;
        c++;
    }

    tabuadaHTML += "</ul>";
    saida.innerHTML += tabuadaHTML;
}
