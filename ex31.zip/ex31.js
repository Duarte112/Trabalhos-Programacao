var deuses = ['Aegir', 'Aud', 'Balder'];

console.log("Comprimento do array deuses:", deuses.length);

console.log("Exibindo os elementos do array com um loop for:");
for (var i = 0; i < deuses.length; i++) {
    alert(deuses[i]);
}

console.log("Exibindo os elementos do array com forEach:");
deuses.forEach(function(deus) {
    alert(deus);
});

deuses.push('Loki', 'Odin', 'Frey');

console.log("Exibindo os elementos do array com map:");
deuses.map(function(deus) {
    alert(deus);
});

console.log("Comprimento atualizado do array deuses:", deuses.length);
