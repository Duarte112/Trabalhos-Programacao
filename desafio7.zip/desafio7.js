document.getElementById("converterBtn").addEventListener("click", function() {
    converter();
});

function converter() {
    var euros = document.getElementById("euros").value;
    var dolares = euros * 1.13; // Taxa de câmbio aproximada
    var reais = euros * 6.33; // Taxa de câmbio aproximada

    var resultado = "Com " + euros + " euros, você terá aproximadamente: <br>" +
                    dolares.toFixed(2) + " dólares  <br>" +
                    reais.toFixed(2) + " reais.";

    document.getElementById("resultado").innerHTML = resultado;
}
