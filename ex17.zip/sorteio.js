function gerar() {
    let min = 1;
    let max = 100;
    let dif = max - min;
    let aleatorio = Math.random();
    let num = min + Math.trunc(dif * aleatorio);

    // Exibir o número gerado na seção "result"
    let result = document.getElementById('result');
    result.innerHTML = `<p>O número gerado é: ${num}</p>`;
}

function limpar() {
    let result = document.getElementById('result');
    result.innerHTML = '<p>Cada vez que você apertar o botão acima, eu penso em um número entre 1 e 100.</p>';
}
