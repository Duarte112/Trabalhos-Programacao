function contagem() {
    let saida = document.getElementById('saida');
    let n1 = Number(document.getElementById('fn1').value);
    let n2 = Number(document.getElementById('fn2').value);
    let cont = '';

    // Verificar se os valores inseridos são numéricos
    if (isNaN(n1) || isNaN(n2)) {
        saida.innerHTML = "<p>Por favor, insira valores numéricos válidos.</p>";
        return;
    }

    // Verificar se n1 é menor ou igual a n2 para uma contagem crescente
    if (n1 <= n2) {
        for (let i = n1; i <= n2; i++) {
            cont += i + " ";
        }
    } else { // Se n1 for maior que n2, realizar uma contagem regressiva
        for (let i = n1; i >= n2; i--) {
            cont += i + " ";
        }
    }

    saida.innerHTML = "<h2>Contando de " + n1 + " até " + n2 + "</h2>";
    saida.innerHTML += "<p>" + cont + "</p>";
}
