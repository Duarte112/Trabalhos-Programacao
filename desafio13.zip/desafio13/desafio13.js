document.addEventListener("DOMContentLoaded", function() {
    const bear = document.getElementById('bear');
    let step = 1;
    let leftPos = 0;
    let isMovingRight = true;
  
    function animateBear() {
      if (step === 1) {
        bear.src = '1.png';
      } else if (step === 2) {
        bear.src = '2.png';
      } else if (step === 3) {
        bear.src = '3.png';
      }
  
      if (isMovingRight) {
        leftPos += 2; // Aumenta a velocidade do movimento
        bear.style.left = leftPos + 'px';
  
        // Se o urso chegar a 300px de distância da esquerda, pare o movimento
        if (leftPos >= 300) {
          isMovingRight = false;
        }
      }
  
      step = step === 3 ? 1 : step + 1;
  
      // Quando o urso chegar ao final da tela, reinicie a posição
      if (leftPos >= window.innerWidth) {
        leftPos = -bear.clientWidth;
        isMovingRight = true;
      }
    }
  
    setInterval(animateBear, 100); // Altera a cada 0.5 segundos
  });
  