function contar() {
    let saida = document.getElementById('saida');
    saida.innerHTML = ''; // Limpar o conteúdo anterior

    saida.innerHTML += '<h2>Contando de 10 até 1</h2>';

    let i = 10;

    function adicionarNumero() {
        if (i >= 1) {
            saida.innerHTML += `<p>${i}</p>`;
            i--;

            if (i === 0) {
                // Quando a contagem atingir 1, redirecione para o vídeo do YouTube
                window.location.href = 'https://www.youtube.com/watch?v=4-UbHw8eDzM&t=36s';
            } else {
                setTimeout(adicionarNumero, 1000); // Aguarda 1 segundo e chama a função novamente
            }
        }
    }

    adicionarNumero();
}
