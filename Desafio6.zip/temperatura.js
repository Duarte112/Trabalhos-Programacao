function converterTemperaturas() {
    // Obter a temperatura em Celsius
    var temperaturaEmCelsius = parseFloat(document.getElementById("celsius").value);

    // Verificar se a entrada é válida
    if (!isNaN(temperaturaEmCelsius)) {
        // Converter para Kelvin e Fahrenheit
        var temperaturaEmKelvin = temperaturaEmCelsius + 273.15;
        var temperaturaEmFahrenheit = (temperaturaEmCelsius * 9/5) + 32;

        // Exibir os resultados na seção correspondente
        var resultados = document.getElementById("resultados");
        resultados.innerHTML = "<p>Temperatura em Kelvin: " + temperaturaEmKelvin.toFixed(2) + " K</p>" +
                               "<p>Temperatura em Fahrenheit: " + temperaturaEmFahrenheit.toFixed(2) + " °F</p>";
    } else {
        alert("Por favor, digite uma temperatura válida em Celsius.");
    }
}
