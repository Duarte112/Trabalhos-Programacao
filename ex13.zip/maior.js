function maior() {
    // Array para armazenar os números
    var numeros = [];

    // Solicitar ao usuário os números até que ele insira '1'
    while (true) {
        var entrada = prompt("Digite um número (ou digite '1' para calcular o maior número):");

        // Se o usuário digitar 'fim', sair do loop
        if (entrada.toLowerCase() === "1") {
            break;
        }

        // Converter a entrada para um número e verificar se é válido
        var numero = parseFloat(entrada);
        if (!isNaN(numero)) {
            numeros.push(numero);
        } else {
            alert("Por favor, digite um número válido ou '1'.");
        }
    }

    // Verificar se foram inseridos números suficientes
    if (numeros.length === 0) {
        alert("Nenhum número foi inserido.");
        return;
    }

    // Determinar o maior número
    var maiorNumero = numeros[0];
    for (var i = 1; i < numeros.length; i++) {
        if (numeros[i] > maiorNumero) {
            maiorNumero = numeros[i];
        }
    }

    // Exibir o resultado na seção correspondente
    var saida = document.getElementById("saida");
    saida.innerHTML = "<p>O maior número é: " + maiorNumero + "</p>";
}
