function calc() {
    let n1 = Number(prompt('Primeiro valor:'));
    let n2 = Number(prompt('Segundo valor:'));
    let op = Number(prompt(`Valores informados: ${n1} e ${n2}. \nO que vamos fazer? \n[1] Somar \n[2] Subtrair \n[3] Multiplicar \n[4] Dividir`));

    let resultado;

    if (op === 1) { // Somar
        resultado = n1 + n2;
    } else if (op === 2) { // Subtrair
        resultado = n1 - n2;
    } else if (op === 3) { // Multiplicar
        resultado = n1 * n2;
    } else if (op === 4) { // Dividir
        resultado = n1 / n2;
    } else {
        resultado = "Opção inválida";
    }

    let saida = document.getElementById('saida');
    saida.innerText = `Resultado: ${resultado}`;
}
