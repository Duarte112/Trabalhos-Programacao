// Função para exibir o contador regressivo
function iniciarContador() {
    var contadorDiv = document.getElementById('contador');
    var segundos = 5;
  
    // Função para atualizar o contador a cada segundo
    var atualizarContador = function() {
      contadorDiv.innerHTML = '<img src="' + segundos + '.png" alt="' + segundos + '">';
  
      segundos--;
  
      // Se chegarmos a 0, parar o contador
      if (segundos < 0) {
        clearInterval(intervalo);
        contadorDiv.innerHTML = "FIM";
      }
    };
  
    // Chamar a função de atualização do contador a cada segundo
    var intervalo = setInterval(atualizarContador, 1000);
  }
  
  // Chamar a função para iniciar o contador quando a página carregar
  window.onload = function() {
    iniciarContador();
  };
  