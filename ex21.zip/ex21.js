function contar() {
    let saida = document.getElementById('saida');
    saida.innerHTML = ''; // Limpar o conteúdo anterior

    saida.innerHTML += '<h2>Contando de 1 até 10</h2>';

    for (let i = 1; i <= 10; i++) {
        saida.innerHTML += `<p>${i}</p>`;
    }
}
