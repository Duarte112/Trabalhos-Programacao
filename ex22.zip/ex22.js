function contar() {
    let saida = document.getElementById('saida');
    saida.innerHTML = ''; // Limpar o conteúdo anterior

    saida.innerHTML += '<h2>Contando de 1 até 10 (marcando os numeros pares)</h2>';

    for (let i = 1; i <= 10; i++) {
        // Adiciona a classe 'par' aos números pares
        let classe = (i % 2 === 0) ? 'par' : '';
        saida.innerHTML += `<p class="${classe}">${i}</p>`;
    }
}