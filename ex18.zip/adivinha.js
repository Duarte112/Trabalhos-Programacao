let res = document.querySelector('section#result');
let computador = 0;

function sortear() {
    let min = 1;
    let max = 5;
    let dif = max - min;
    let aleatorio = Math.random();
    computador = min + Math.trunc(dif * aleatorio);
}

function jogar() {
    let palpite = prompt("Digite seu palpite entre 1 e 5:");

    palpite = parseInt(palpite);

    if (!isNaN(palpite)) {
        if (palpite === computador) {
            res.innerHTML = "<p>Parabéns! Você acertou!</p>";
        } else {
            res.innerHTML = "<p>Ops! Tente novamente.</p>";
        }
    } else {
        res.innerHTML = "<p>Por favor, digite um número válido.</p>";
    }
}

// Chame a função sortear quando a página carregar
window.onload = sortear;
