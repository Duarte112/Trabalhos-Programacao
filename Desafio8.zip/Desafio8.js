document.getElementById('descontoForm').addEventListener('submit', function(event) {
    event.preventDefault(); // Evita o recarregamento da página

    // Obter valores do formulário
    var produto = document.getElementById('produto').value;
    var preco = parseFloat(document.getElementById('preco').value);

    // Calcular desconto (10%)
    var desconto = preco * 0.1;
    var precoFinal = preco - desconto;

    // Exibir resultado
    document.getElementById('precoOriginal').textContent = preco.toFixed(2) + ' €';
    document.getElementById('desconto').textContent = desconto.toFixed(2) + ' €';
    document.getElementById('precoFinal').textContent = precoFinal.toFixed(2) + ' €';

    // Mostrar o resultado
    document.getElementById('resultado').style.display = 'block';
});
