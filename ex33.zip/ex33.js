var deuses = ['Aegir', 'Aud', 'Balder', 'Bragi', 'Búri', 'Dag', 'Dellingr'];

var nomesUl = document.getElementById("nomes");

// Exibindo todos os nomes na lista
deuses.forEach(function(nome) {
    var li = document.createElement("li");
    li.textContent = nome;
    nomesUl.appendChild(li);
});

// Adicionando um novo nome quando o botão é clicado
document.getElementById("adicionarNome").addEventListener("click", function() {
    var novoNome = document.getElementById("novoNome").value;
    if (novoNome.trim() !== "") {
        deuses.push(novoNome);
        var novoLi = document.createElement("li");
        novoLi.textContent = novoNome;
        nomesUl.appendChild(novoLi);
        document.getElementById("novoNome").value = "";
    }
});
