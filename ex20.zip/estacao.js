function estacao() {
    let mes = prompt('Diga o mês em extenso (ex: Setembro)').toLowerCase();
    let saida = document.querySelector('section#saida');
    let estacao;

    // Mapear a estação do ano para alguns países
    const estacoesPorMes = {
        janeiro: 'Inverno',
        fevereiro: 'Inverno',
        março: 'Primavera',
        abril: 'Primavera',
        maio: 'Primavera',
        junho: 'Verão',
        julho: 'Verão',
        agosto: 'Verão',
        setembro: 'Outono',
        outubro: 'Outono',
        novembro: 'Outono',
        dezembro: 'Inverno'
    };

    // Verificar se o mês está no mapa
    if (estacoesPorMes.hasOwnProperty(mes)) {
        estacao = estacoesPorMes[mes];
        saida.innerHTML = `Em Portugal, é ${estacao}.`;
    } else {
        saida.innerHTML = 'Mês inválido. Por favor, insira um mês válido.';
    }
}

// Associar a função ao botão
document.getElementById('botao').addEventListener('click', estacao);
