function calcularMedia() {
    console.log("Botão clicado!"); // Isso deve aparecer no console se a função for chamada
    var notas = []; // Array para armazenar as notas

    // Loop para obter as notas do usuário
    while (true) {
        var nota = parseFloat(prompt("Digite a nota (ou digite '1' para calcular a média):"));
        
        // Verificar se a entrada é válida
        if (isNaN(nota) && nota !== 0) {
            alert("Por favor, digite um número válido ou '1' para calcular a média.");
            continue;
        }

    // Se '1' for digitado, calcular a média e sair do loop
    if (nota == "1" || nota == 0) {
        if (notas.length === 0) {
        alert("Nenhuma nota foi inserida.");
        return;
    }
    break;
}

        // Adicionar a nota ao array
        notas.push(nota);
    }

    // Calcular a média
    var total = 0;
    for (var i = 0; i < notas.length; i++) {
        total += notas[i];
    }
    var media = total / notas.length;

    // Determinar a situação do aluno
    var situacao = "";
    if (media >= 10) {
        situacao = "Aprovado";
    } else {
        situacao = "Reprovado";
    }

    // Exibir o resultado na seção correspondente
    var resultado = document.getElementById("situacao");
    resultado.innerHTML = "<p>A média é: " + media.toFixed(2) + ". Situação: " + situacao + "</p>";
}
