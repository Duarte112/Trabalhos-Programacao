var button = document.getElementById("startButton");
var mostrador = document.getElementById("mostrador");

button.addEventListener('click', function() {
    new Timer(1, mostrador, function() { 
        alert('O tempo acabou!');
    }).start();
});

function Timer(mins, target, cb) {
    this.counter = mins * 60;
    this.target = target;
    this.callback = cb;
}

Timer.prototype.pad = function(s) { 
    return (s < 10) ? '0' + s : s;
}

Timer.prototype.start = function() { 
    this.count();
}

Timer.prototype.stop = function() { 
    clearInterval(this.clock);
}

Timer.prototype.done = function() { 
    if (this.callback) this.callback();
}

Timer.prototype.display = function(s) { 
    var minutes = Math.floor(s / 60);
    var seconds = s % 60;
    this.target.innerHTML = this.pad(minutes) + ":" + this.pad(seconds);
}

Timer.prototype.count = function() { 
    var self = this;
    self.display(self.counter);
    self.clock = setInterval(function() {
        self.counter--;
        self.display(self.counter);
        if (self.counter < 0) { 
            clearInterval(self.clock);
            self.done();
        }
    }, 1000);
}
