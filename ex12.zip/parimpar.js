function parimpar() {
    // Solicitar ao usuário um número
    var numero = parseInt(prompt("Digite um número inteiro:"));

    // Verificar se o número é válido
    if (isNaN(numero)) {
        alert("Por favor, digite um número inteiro válido.");
        return;
    }

    // Verificar se o número é par ou ímpar
    var resultado = (numero % 2 === 0) ? "O número é par." : "O número é ímpar.";

    // Exibir o resultado na seção correspondente
    var resultElement = document.getElementById("result");
    resultElement.innerHTML = "<p>" + resultado + "</p>";
}
